// import './App.css';

function Footer() {
    return (
        <>
            <h4>Oi! Eu moro no footer!</h4>
        </>
    )
}

export default Footer