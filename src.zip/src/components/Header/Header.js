// import './App.css';

function Header() {
    return (
        <>
            <h1>Video</h1>
            <input type="text" placeholder="Busca" id="campoDeBusca"></input>
        </>
    )
}

export default Header